# Maneasy

<a href="https://imgur.com/hRFJdmH"><img src="https://i.imgur.com/hRFJdmH.jpg" title="source: imgur.com" /></a>

# CO.DE School
SENAI + Fundação Grupo Volkswagen


# Sobre o projeto:
Maneasy, é um sistema de gerenciamento e alocação de profissionais de TI, permitindo cadastrar e consultar os recursos alocados em projetos, demandas e atendimento de chamados dentro da área da Tecnologia.

• Acesse o manual da marca, clicando [aqui.](https://www.canva.com/design/DAFglhtjNB0/a193T7KIrkSvyGkda8jfqw/edit?utm_content=DAFglhtjNB0&utm_campaign=designshare&utm_medium=link2&utm_source=sharebutton)

• Acesse o prótotipo de baixa e alta qualidade e o guia de estilo, clicando [aqui.](https://www.figma.com/file/zKDXfkQNWlcK7Xr1beANBH/Prototipa%C3%A7%C3%A3o---Maneasy?type=design&node-id=1%3A3&t=9s5NZZMLBTD35XYA-1)


# Grupo

<table>
  
  <tr>
      <td>Claudio Francisco Porto</td>
      <td><a href="https://github.com/98claudio"><img src="https://i.imgur.com/IM8RKWM.png" title="GitHub" /></a></td>
      <td><a href="#"><img src="https://i.imgur.com/AKLwkB5.png" title="Linkedin" /></a></td>
  </tr>
  
 <tr>
     <td>Gustavo Luiz Miranda</td>
     <td><a href="https://github.com/guusluiz"><img src="https://i.imgur.com/IM8RKWM.png" title="GitHub" /></a></td>
     <td><a href="https://www.linkedin.com/in/gustavo-luiz-miranda/"><img src="https://i.imgur.com/AKLwkB5.png" title="Linkedin" /></a></td>
 </tr>
  
  <tr>
      <td>Hosmairys Yuriannys Holder Rodriguez</td>
      <td><a href="https://github.com/Hosmairys"><img src="https://i.imgur.com/IM8RKWM.png" title="GitHub" /></a></td>
      <td><a href="https://www.linkedin.com/in/hosmairys-holder-1a9896208/"><img src="https://i.imgur.com/AKLwkB5.png" title="Linkedin" /></a></td>
  </tr>
  
 <tr>
     <td>Jhonatan Pereira Ferreira</td>
     <td><a href="https://github.com/jhonatanferreira94"><img src="https://i.imgur.com/IM8RKWM.png" title="GitHub" /></a></td>
     <td><a href="https://www.linkedin.com/in/jhonatanferr/"><img src="https://i.imgur.com/AKLwkB5.png" title="Linkedin" /></a></td>
 </tr>
  
 <tr>
     <td>Lucas Oliveira</td>
     <td><a href="https://github.com/Lucca-gOn"><img src="https://i.imgur.com/IM8RKWM.png" title="GitHub" /></a></td>
     <td><a href="https://www.linkedin.com/in/lucas-oliveira-913045269/"><img src="https://i.imgur.com/AKLwkB5.png" title="Linkedin" /></a></td>
 </tr>
  
 <tr>
     <td>Priscila Laurentino</td>
     <td><a href="https://github.com/PriLaurentino"><img src="https://i.imgur.com/IM8RKWM.png" title="GitHub" /></a></td>
     <td><a href="https://www.linkedin.com/in/priscila-laurentino-a2367061/"><img src="https://i.imgur.com/AKLwkB5.png" title="Linkedin" /></a></td>
 </tr>

</table>


