package api.maneasy.dtos;

public record TokenDto(String token) {}