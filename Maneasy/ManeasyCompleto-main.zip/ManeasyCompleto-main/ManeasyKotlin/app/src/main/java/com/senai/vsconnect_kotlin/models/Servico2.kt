package com.senai.vsconnect_kotlin.models

import java.util.*

class Servico2 (
    val id: UUID,
    val tipoServicos: Boolean,
    val statusServicos: String,
    val descricaoServicos: String
)