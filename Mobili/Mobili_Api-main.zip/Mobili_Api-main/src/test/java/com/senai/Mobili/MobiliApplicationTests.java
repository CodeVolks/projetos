package com.senai.Mobili;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MobiliApplicationTests {

	@Test
	void contextLoads() {
	}

}
