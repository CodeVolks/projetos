package com.senai.Mobili;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MobiliApplication {

	public static void main(String[] args) {
		SpringApplication.run(MobiliApplication.class, args);
	}

}
