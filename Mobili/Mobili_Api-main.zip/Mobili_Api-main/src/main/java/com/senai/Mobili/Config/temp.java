package com.senai.Mobili.Config;


//OPA
public class temp {
}
