package com.senai.Mobili.Dtos;

public record TokenDto(String token) {
}
