import "./style.css"
import { useEffect, useState } from "react";
import { Link } from "react-router-dom";

function CadastroAdmFrota() {
    return (
        <>
            <p>Teste</p>
        </>
    )
}

export default CadastroAdmFrota;