import "./style.css";
import imgLogo from "../../assets/img/logo.png";
import { Link } from "react-router-dom";
import React from 'react'
import ReactDOM from 'react-dom/client'


function Ofertas() {
    
}