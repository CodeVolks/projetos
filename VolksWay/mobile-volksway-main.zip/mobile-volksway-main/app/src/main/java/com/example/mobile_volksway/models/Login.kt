package com.example.mobile_volksway.models

class Login (
    val email: String,
    val senha: String
)