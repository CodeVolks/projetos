package com.example.mobile_volksway.models

import java.util.*

class Veiculo (

    val id: UUID,
    val usuario: String,
    val marca: String,
    val placa: String,
    val codigo_chassi: String
)