package com.example.mobile_volksway.models

import java.util.*

class Usuario (
    val id: UUID,
    val nome: String,
    val telefone: String,
    val email: String,
    val senha: String,
    val data_nascimento: Date,
    val cidade: String,
    val cpf: String,
    val tipo_usuario: String,
    val img: String,
)

