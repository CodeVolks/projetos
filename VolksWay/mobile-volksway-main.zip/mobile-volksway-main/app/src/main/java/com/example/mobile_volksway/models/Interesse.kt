package com.example.mobile_volksway.models

import java.util.*

class Interesse (
    val id: UUID,
    val propaganda: String,
    val usuario: String,
    val meio_contato_email: Boolean
)