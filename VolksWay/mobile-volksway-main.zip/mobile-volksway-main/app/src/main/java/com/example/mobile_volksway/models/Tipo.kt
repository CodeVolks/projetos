package com.example.mobile_volksway.models

import java.util.*

class Tipo {
 /*
    val tipo: String,
*/
}