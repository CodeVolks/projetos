package com.example.mobile_volksway.models

import java.util.*

class Checklist (

    val id: UUID,
    val freio: Boolean,
    val combustivel: Boolean,
    val oleo: Boolean,
    val ar_condicionado: Boolean,
    val data_criado: Boolean,
    val foto_pneu: String ,
    val estado_pneu: String
)