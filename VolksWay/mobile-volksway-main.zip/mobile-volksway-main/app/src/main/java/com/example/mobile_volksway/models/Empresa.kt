package com.example.mobile_volksway.models

import java.util.UUID

class Empresa (
    val id: UUID,
    val razao_social: String,
    val cidade: String,
    val cnpj: String
)
