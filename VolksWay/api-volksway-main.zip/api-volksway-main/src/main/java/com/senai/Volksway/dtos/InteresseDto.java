package com.senai.Volksway.dtos;

import com.senai.Volksway.models.PropagandaModel;
import com.senai.Volksway.models.UsuarioModel;
import jakarta.validation.constraints.NotBlank;

import java.util.UUID;

public record InteresseDto(
        UUID id_propaganda,
        UUID id_usuario,

        boolean meio_contato_email) {

}