package com.senai.Volksway.dtos;

public record TokenDto(String token) {}
