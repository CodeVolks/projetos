package com.gws.api.apigws.models;

public enum TipoPrioridadeModel {
    ALTA,
    MEDIA,
    BAIXA

}
