package com.gws.api.apigws.models;

public enum TipoStatusModel {
    EM_PROGRESSO,
    PARA_INICIAR,
    COMPLETOS,
    CANCELADOS;


}
