package com.gws.api.apigws.services;

public class FTEService {
}
