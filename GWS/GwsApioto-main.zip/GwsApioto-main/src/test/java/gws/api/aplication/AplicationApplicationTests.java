package gws.api.aplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AplicationApplicationTests {

	@Test
	void contextLoads() {

	}

}
