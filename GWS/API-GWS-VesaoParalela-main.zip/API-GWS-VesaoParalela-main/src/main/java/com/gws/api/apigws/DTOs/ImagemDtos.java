package com.gws.api.apigws.DTOs;

import org.springframework.web.multipart.MultipartFile;

public record ImagemDtos(
        MultipartFile imagem
) {
}
