package com.gws.api.apigws.models;

public enum TipoStatusModel {
    EM_PROGRESSO,
    NOVO,
    COMPLETOS,
    CANCELADOS;


}
