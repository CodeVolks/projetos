# API-GWS-VesaoParalela
 
