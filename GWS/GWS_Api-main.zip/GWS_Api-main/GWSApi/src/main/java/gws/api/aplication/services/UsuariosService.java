package gws.api.aplication.services;

import org.springframework.stereotype.Service;

@Service
public class UsuariosService {
}
