package com.gws.api.apigws.models;

public enum TipoConclusao {
    NAO_CONCLUIDO,
    PARCIALMENTE_CONCLUIDO,
    MINIMO_CONCLUIDO,
    TUDO_CONCLUIDO;
}
