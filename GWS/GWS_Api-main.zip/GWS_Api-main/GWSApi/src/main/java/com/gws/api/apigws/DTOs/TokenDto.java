package com.gws.api.apigws.DTOs;

public record TokenDto (String token){
}
