//Imports
import axios from "axios";

//SoftSkills
export const softResource = "/softskills";
//HardSkills
export const hardResource = "/hardskills";
//LoginSkills
export const loginResource = "/login";
//Demands
export const demandsResource = "/demandas/lista-demandas";

export const localApiUrl = `https://api-gws.azurewebsites.net`;

const api = axios.create({
  baseURL: localApiUrl,
});

export default api;