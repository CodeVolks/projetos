import React from 'react';
import BreadCrumb from '../../../Components/Common/BreadCrumb';
import { Container } from 'reactstrap';
import List from './List';

const DemandList = () => {
    document.title = "Listar Demandas | GWS";
    return (
        <React.Fragment>
            <div className="page-content">
                <Container fluid>
                    <BreadCrumb title="Listar Demandas" pageTitle="Demandas" />
                    <List />
                </Container>
            </div>
        </React.Fragment>
    );
};

export default DemandList;