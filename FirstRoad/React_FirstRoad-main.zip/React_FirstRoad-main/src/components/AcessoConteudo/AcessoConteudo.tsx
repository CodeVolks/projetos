import { Link } from "react-router-dom"


const AcessoConteudo = () => {
    return(
        <section>
            <h1>
                Bem Vindos
            </h1>

            <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Fugit delectus laborum magni error aut non, soluta commodi rerum officia odio dolorum velit natus architecto eveniet, aspernatur dolor placeat et nemo.
            Lorem ipsum dolor, sit amet consectetur adipisicing elit. Fugit delectus laborum magni error aut non, soluta commodi rerum officia odio dolorum velit natus architecto eveniet, aspernatur dolor placeat et nemo.
            Lorem ipsum dolor, sit amet consectetur adipisicing elit. Fugit delectus laborum magni error aut non, soluta commodi rerum officia odio dolorum velit natus architecto eveniet, aspernatur dolor placeat et nemo.
            </p>

            <div>
                <Link to=""></Link>
                <Link to=""></Link>
                <Link to=""></Link>
                <Link to=""></Link>
            </div>
        </section>
    )
}
export default AcessoConteudo