package apiFirstRoad.apiFirstRoad.dto;


public record TokenDto(String token) {}
