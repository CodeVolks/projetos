package apiFirstRoad.apiFirstRoad;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiFirstRoadApplicationTests {

	@Test
	void contextLoads() {
	}

}
