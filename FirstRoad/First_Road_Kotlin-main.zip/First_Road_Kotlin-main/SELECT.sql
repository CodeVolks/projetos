SELECT *, BIN_TO_UUID(id)as id  FROM tb_unidades;

SELECT *, BIN_TO_UUID(id)as id  FROM tb_tipos_usuario;

SELECT *, BIN_TO_UUID(id)as id  FROM tb_unidades_organizacionaistb_trilha_conteudotb_unidadestb_unidades_organizacionaistb_unidades_organizacionais;
