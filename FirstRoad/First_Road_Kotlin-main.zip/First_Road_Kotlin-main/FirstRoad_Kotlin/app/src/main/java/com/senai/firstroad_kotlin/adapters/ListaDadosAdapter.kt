package com.senai.vsconnect_kotlin.adapters

class ListaDadosAdapter {
}