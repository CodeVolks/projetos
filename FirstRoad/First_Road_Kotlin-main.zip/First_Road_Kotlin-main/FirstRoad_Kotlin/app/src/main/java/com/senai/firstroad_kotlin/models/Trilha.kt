package com.senai.vsconnect_kotlin.models

class Trilha(
     val titulo_trilha: String,
     val descricao_trilha: String
)