package com.senai.vsconnect_kotlin.components

class DadosFragment {

}